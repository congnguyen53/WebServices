function password1(){
    var str = document.signup.password.value;
    var str1 = document.signup.cpassword.value;
    console.log(str);
    console.log(str1);
    if( str !== str1){
        alert("Password does not match!");
        document.signup.cpassword.value = "";
        location.reload();
    }
}
function fullnameF()
{
    var str = document.signup.fullname.value;
    var re = /^[a-zA-Z]+\s[a-zA-Z]+$/;  // \s means white space.
    var result = re.test(str);
    if(result == false)
    {
        alert("not valid!");
        location.reload();
        document.signup.fullname.value = "";
    }
}


function emailF()
{
    var str = document.signup.email.value;
    var re =/^[a-zA-Z0-9]+(\.[a-aA-z0-9]+)*@[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)*(\.[a-z]{2,3})$/;
    var result = re.test(str);
    if(result == false)
    {
        alert("not valid!");
        document.signup.email.value = "";
        location.reload();
    }

}
function username()
{
    var str = document.signup.username.value;
    var re =/^[a-zA-Z0-9]+(\.[a-aA-z0-9]+)$/;
    var result = re.test(str);
    if(result == false)
    {
        alert("not valid!");
        document.signup.email.value = "";
        location.reload();
    }

}

function birthdayF() // 30 points
{
    //implement the code that validate birthdays here... 30 points
    var str = document.signup.birthday.value;
    const re = /^(0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])[\/\-]\d{4}$/;

    //([0-1]?[0-9])\/ --> allows the user to enter the month with or without a preceding 0 followed by '/'
    //([0-3]?[0-9])\/ --> allows the user to enter the day with or without a preceding 0 followed by '/'
    //([0-9]?[0-9]?[0-9][0-9]) --> allows the user to enter the year with or without preceding 2 digits
    //For example, 1998 or 98 would be accepted

    var result = re.test(str);
    console.log(re)
    console.log(str)
    console.log(result);
    console.log(str.match(re));

    if(result)
    {


        //Test which seperator is used '/' or '-'
        var opera1 = str.split('/');
        var opera2 = str.split('-');
        lopera1 = opera1.length;
        lopera2 = opera2.length;
        // Extract the string into month, date and year
        if (lopera1>1)
        {
            var pdate = str.split('/');
        }
        else if (lopera2>1)
        {
            var pdate = str.split('-');
        }

        var mm = parseInt(pdate[0]);
        var dd  = parseInt(pdate[1]);
        var yy = parseInt(pdate[2]);
        // Create list of days of a month [assume there is no leap year by default]
        var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31];
        if (mm==1 || mm>2)
        {
            if (dd>ListofDays[mm-1])
            {
                alert('Invalid date format1!');
                document.signup.birthday.value = "";
                location.reload();
            }
        }
        if (mm==2)
        {
            var lyear = false;
            if ( (!(yy % 4) && yy % 100) || !(yy % 400))
            {
                lyear = true;
            }
            if ((lyear==false) && (dd>=29))
            {
                alert('Invalid date format2!');
                document.signup.birthday.value = "";
                location.reload();
            }
            if ((lyear==true) && (dd>29))
            {
                alert('Invalid date format3!');
                document.signup.birthday.value = "";
                location.reload();
            }
        }
    }
    else
    {
        alert("Invalid date format!");
        document.signup.birthday.value = "";
        location.reload();
    }

}

function phoneF()
{
    var str = document.signup.phone.value;
    var re = /^([0-9]{3})-([0-9]{3})-([0-9]{4})$/;
    var result = re.test(str);
    if(result == false)
    {
        alert("not valid!");
        document.signup.phone.value = "";
        location.reload();
    }
}

