const sqlite3 = require('sqlite3').verbose();

let db = new sqlite3.Database('./test.db',(err)=>{
    if(err){
        console.log(err.message)
    }
    console.log('connected to test db in sqlie')
});
db.serialize(function() {
    db.run("CREATE TABLE lorem (info TEXT)");

    var stmt = db.prepare("INSERT INTO lorem VALUES (?)",(err)=>{
        if(err){
            console.log("error")
        }
    });
    for (var i = 0; i < 10; i++) {
        stmt.run("Ipsum " + i);
    }
    stmt.finalize();

    db.each("SELECT * FROM lorem", function(err, row) {
        console.log(row.id + ": " + row.info);
    });
});

db.close();