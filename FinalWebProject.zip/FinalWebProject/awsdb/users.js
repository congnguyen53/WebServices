const mysql = require('mysql');

const LocalStrategy = require('passport-local').Strategy
const bcrypt = require('bcrypt')



var getinfo = function(callback) {
    var con = mysql.createConnection({
        host: "webdb.c6kdg7mgrzji.us-east-2.rds.amazonaws.com",
        user: "admin",
        password: "Cc!0936481998",
        database: "WebService"
    });
    con.connect(function (err) {
        if (err) throw err;
        con.query("SELECT * FROM WebService.LoginInfo", function (err, result, fields) {
            if (err) throw err;
            var resultArray = Object.values(JSON.parse(JSON.stringify(result)));
            callback(null,resultArray);
            con.end();
            });
        });

    };

getinfo(function(err,result){
    console.log(result)
});
exports.findById = function(id, cb) {
    getinfo(function (err, result) {


        for (var i = 0, len = result.length; i < len; i++) {
            var record = result[i];

            if (record.id === id) {
                cb(null, result[i]);
            }
        }

    });
};
exports.findByUsername = function(username, cb) {
    getinfo(function (err, result) {
        for (var i = 0, len = result.length; i < len; i++) {
            var record = result[i];
            if (record.username === username) {
                return cb(null, record);
            }
        }
        return cb(null, null);
    });
};



