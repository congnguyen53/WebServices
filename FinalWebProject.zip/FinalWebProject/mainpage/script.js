var jsdom = require("jsdom");
const mysql = require('mysql');
const { JSDOM } = jsdom;
const { window } = new JSDOM();
const { document } = (new JSDOM('')).window;
global.document = document;
var $ = jQuery = require('jquery')(window);

$(document).ready(function ()
{
    $(".text").click(function ()
    {
        $(".overlay").fadeIn(500);
    });
    $(".overlay").not(".text").click(function()
    {
        $(".overlay").fadeOut(500);
    });
    $("[type = submit]").click(function ()
    {
        var post = $("textarea").val();
        $("<p class='post'>" + post + "</p>").appendTo("section");
    });
});
exports.GetPost = function(username, cb) {
    var con = mysql.createConnection({
        host: "webdb.c6kdg7mgrzji.us-east-2.rds.amazonaws.com",
        user: "admin",
        password: "Cc!0936481998",
        database: "WebService"
    });
    con.connect(function (err) {
        if (err) throw err;
        console.log(username)
        var sql = "SELECT * FROM WebService.Userpost WHERE username ="+ "'"+username+ "'"
        con.query(sql, function (err, result) {
            if (err) throw err;
            console.log(result)
            con.end();
        });
    });
};
