
const bcrypt = require('bcrypt');
const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const app = express();
const db = require('./awsdb');
const mysql = require('mysql');

//middleware here-------------------------------------------
app.use(cookieParser());
app.use('/', express.static(path.join(__dirname,'/client')));
app.use('/signup', express.static(path.join(__dirname,'/registration')));

const main = require('./mainpage/export');

//password authentication with passport------------------------------------------------------------------
var passport = require('passport');
var Strategy = require('passport-local').Strategy;
app.use(require('morgan')('combined'));
app.use(require('body-parser').urlencoded({ extended: true }));
app.use(require('express-session')({ secret: 'Session', resave: false, saveUninitialized: false }));
app.use(passport.initialize());
app.use(passport.session());
//Check Password
passport.use(new Strategy(

    function(username, password, cb) {
        db.users.findByUsername(username, function(err, user) {
            if (err) { return cb(err); }
            if (!user) { return cb(null, false); }
            if((bcrypt.compareSync(password, user.password))){return cb(null, user);}
            if (user.password != password) { return cb(null, false); }
            return cb(null, user);
        });
    }));
passport.serializeUser(function(user, cb) {
    cb(null, user.id);
});
passport.deserializeUser(function(id, cb) {
    db.users.findById(id, function (err, user) {
        if (err) { return cb(err); }
        cb(null, user);
    });
});
app.post('/login',
    passport.authenticate('local', { failureRedirect: '/error' }),
    function(req, res) {
        res.redirect('/success?username='+req.user.username);
    });
app.use( express.static(path.join(__dirname,'/mainpage/style.css')));
app.get('/success', function( req, res,err) {
        res.sendFile(path.join(__dirname, '/mainpage/index.html'));
        //res.send("Welcome "+req.user.username+"!!")
        main.script.GetPost(req.user.username)

    }
);
app.get('/error', (req, res) => res.send("Error!!!"));
app.post('/saveinfo',async function(req,res){

    res.send("<style>table {background-color:#ddeeff;border:1px solid black} td, tr {border:1px solid black;} td {padding:3px;}</style>" +
        "<table><tr><td>Full Name: </td><td>" + req.body.fullname + "</td></tr>" +
        "<tr><td>Username: </td><td>" + req.body.username + "</td></tr>" +
        "<tr><td>Email: </td><td>" + req.body.email + "</td></tr>" +
        "<tr><td>Gender: </td><td>" + req.body.gender + "</td></tr>" +
        "<tr><td>Birthday: </td><td>" + req.body.birthday + "</td></tr>" +
        "<tr><td>Phone Number: </td><td>" + req.body.phone + "</td></tr></table>"+
        "        <div class=\"col\">\n" +
        "            <a href=\"/\" style=\"color:black\"  >Log-In</a>\n" +
        "        </div>");


    var con = mysql.createConnection({
        host: "webdb.c6kdg7mgrzji.us-east-2.rds.amazonaws.com",
        user: "admin",
        password: "Cc!0936481998",
        database: "WebService"
    });
    const hashedPassword = await bcrypt.hash(req.body.password, 10)
    console.log(hashedPassword)
    con.connect(function (err) {
        if (err) throw err;


        var sql = "INSERT INTO WebService.CustomerInfo (fullname,username,password,email,gender,birthday,phone) " +
            "VALUES ('"+req.body.fullname+"','"+req.body.username+"','"+hashedPassword+"','"+req.body.email+"','"+req.body.gender+"','"+req.body.birthday+"','"+req.body.phone+"')";
        con.query(sql, function (err, result) {
            if (err) throw err;



        });
        var sql2 = "INSERT INTO WebService.LoginInfo (username,password,id) " +
            "VALUES ('"+req.body.username+"','"+hashedPassword+"','"+req.body.username+"')";
        con.query(sql2, function (err, result) {
            if (err) throw err;

            con.end();
        });
    });


});
app.get('/logout', function(req, res){
    req.logout();
    res.redirect('/');
});
app.listen(8080, () => console.log('cookie/authentication app listening on port 8080!'));