
const bcrypt = require('bcrypt');
const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const app = express();
const db = require('./awsdb');

//middleware here-------------------------------------------
app.use(cookieParser());
app.use('/', express.static(path.join(__dirname,'/client')));
app.use('/signup', express.static(path.join(__dirname,'/registration')));


//password authentication with passport------------------------------------------------------------------
var passport = require('passport');
var Strategy = require('passport-local').Strategy;
app.use(require('morgan')('combined'));
app.use(require('body-parser').urlencoded({ extended: true }));
app.use(require('express-session')({ secret: 'Session', resave: false, saveUninitialized: false }));
app.use(passport.initialize());
app.use(passport.session());

passport.use(new Strategy(
    function(username, password, cb) {
        db.users.findByUsername(username, function(err, user) {
            if (err) { return cb(err); }
            if (!user) { return cb(null, false); }
            if (user.password != password) { return cb(null, false); }
            return cb(null, user);
        });
    }));
passport.serializeUser(function(user, cb) {
    cb(null, user.id);
});
passport.deserializeUser(function(id, cb) {
    db.users.findById(id, function (err, user) {
        if (err) { return cb(err); }
        cb(null, user);
    });
});
app.post('/login',
    passport.authenticate('local', { failureRedirect: '/error' }),
    function(req, res) {
        res.redirect('/success?username='+req.user.username);
    });
app.get('/success', (req, res) => res.send("Welcome "+req.user.username+"!!"));
app.get('/error', (req, res) => res.send("Error!!!"));

app.listen(8080, () => console.log('cookie/authentication app listening on port 8080!'));